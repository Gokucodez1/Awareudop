        CREATE TABLE IF NOT EXISTS "pl" (
            "user_id"  bigint,
            "pl" TEXT DEFAULT '{}',
            PRIMARY KEY("user_id")
        )