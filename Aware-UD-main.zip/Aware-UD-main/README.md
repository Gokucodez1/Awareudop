# God or Versatility 
Aware's Current Source Code [ Python ]

- The code was made public because i got bored with discord bots lol

# Setup 

- Make a `.env` file and put endpoint url of proxies [ Optional ]
- Put Token in Main.py
- Now Run `docker compose up --build -d`
- Enjoy [ Give Credits ]


# Contributions 
- Shubham , Samarth , Zeck , Xenofic , Rexy , Anay

# Contact 
- https://shxbham.dev/
- wwzp@proton.me
- shubham@gatewaybot.org

Thanks for all the support you guys gave to my projects , I will surely miss these days but discord bots wont get me a job lol
